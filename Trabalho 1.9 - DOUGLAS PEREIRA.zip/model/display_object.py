class DisplayObject:
	def __init__(self, coords, color, is_filled):
		self.coords = coords
		self.color = color
		self.is_filled = is_filled